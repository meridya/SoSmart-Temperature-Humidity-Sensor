ClosedCube Arduino Library for
ClosedCube HDC1080 Low Power High Accuracy Digital I2C Humidity and Temperature Sensor Breakout
=================================================================

This is breakout board for [Texas Instruments HDC1080](http://www.ti.com/product/HDC1080) Low Power High Accuracy Digital Humidity Sensor with Temperature Sensor 


[![](https://github.com/closedcube/ClosedCube_HDC1080_Arduino/blob/master/images/B004_HDC1080_Pic1.jpg)](https://www.tindie.com/stores/closedcube/)
[![](https://github.com/closedcube/ClosedCube_HDC1080_Arduino/blob/master/images/B004_HDC1080_Pic2.jpg)](https://www.tindie.com/stores/closedcube/)



---
### Where to Buy?

[![](http://images.closedcube.uk/logo/github/amazon.png)](https://www.amazon.co.uk/dp/B01GBOGNFE)

| Region  | Link for 2 pcs | Link for 2 pcs (Right-Angle) |
| ------------- | ------------- |------------- |
| Germany (DE) | https://www.amazon.de/dp/B01GBOGNFE |  https://www.amazon.de/dp/B085XKGQBR |
| France (FR) | https://www.amazon.fr/dp/B01GBOGNFE | https://www.amazon.fr/dp/B085XKGQBR |
| Italy (IT) | https://www.amazon.it/dp/B01GBOGNFE | https://www.amazon.it/dp/B085XKGQBR |
| Spain (ES) | https://www.amazon.es/dp/B01GBOGNFE | https://www.amazon.es/dp/B085XKGQBR |
| UK | https://www.amazon.co.uk/dp/B01GBOGNFE | https://www.amazon.co.uk/dp/B085XKGQBR |


[![](http://images.closedcube.uk/logo/github/ebay.gif)](http://www.ebay.co.uk/itm/182129971333)

| Region  | Link |
| ------------- | ------------- |
| Europe,Asia,Oceania | http://www.ebay.co.uk/itm/182129971333  |
| USA  | TBD |


[![](http://images.closedcube.uk/logo/github/tindie.png)](https://www.tindie.com/stores/closedcube/)

https://www.tindie.com/products/7301/



